package com.lab4;

import com.lab4.*;

public class App {
    public static void main(String[] args) {
        // Ejemplo de uso del sistema
        Plan planBase = new PlanBase();
        Plan planPremium = new PlanPremium();

        Usuario usuario = new Usuario("Usuario1", "contraseña123", planBase);
        usuario.registrarse();
        usuario.ingresar();
        usuario.cambiarPlan(planPremium);
        usuario.seleccionar(new Libro());
        usuario.prestar(new EntregaPremium());
        usuario.perfil();
    }
}
