package com.lab4.service;

public interface Entrega {
    String horario();
}
