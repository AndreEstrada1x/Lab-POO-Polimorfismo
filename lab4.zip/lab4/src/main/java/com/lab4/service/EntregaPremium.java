package com.lab4.service;

public class EntregaPremium implements Entrega {
    @Override
    public String horario() {
        return "AM/PM";
    }

}
