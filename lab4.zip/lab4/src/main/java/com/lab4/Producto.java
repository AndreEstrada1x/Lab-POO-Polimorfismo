package com.lab4;

public interface Producto {
    void listar();
}
