package com.lab4;

public interface Plan {
    int plazoMaximo();
}
