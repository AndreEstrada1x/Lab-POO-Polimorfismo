package com.lab4;

public class Revista implements Producto {
    @Override
    public void listar() {
        // Lógica para listar información de la revista
    }
}
