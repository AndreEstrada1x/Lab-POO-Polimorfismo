package com.lab4;

public class PlanPremium implements Plan {
    @Override
    public int plazoMaximo() {
        return 50;
    }
    // Otros métodos específicos del plan premium
}
