package com.lab4;

public class PlanBase implements Plan {
    @Override
    public int plazoMaximo() {
        return 30;
    }
}
