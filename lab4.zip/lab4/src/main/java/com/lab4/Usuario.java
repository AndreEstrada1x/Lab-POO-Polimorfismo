package com.lab4;

import com.lab4.service.Entrega;

public class Usuario {
    private String nombre;
    private String contraseña;
    private Plan plan;

    public Usuario(String nombre, String contraseña, Plan plan) {
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.plan = plan;
    }

    public void registrarse() {
        // Lógica para registrar un usuario
    }

    public void ingresar() {
        // Lógica para ingresar a la aplicación
    }

    public void seleccionar(Producto producto) {
        // Lógica para seleccionar un producto
    }

    public void prestar(Entrega entrega) {
        // Lógica para realizar un préstamo
    }

    public void perfil() {
        // Lógica para gestionar el perfil del usuario
    }

    public void cambiarPlan(Plan nuevoPlan) {
        this.plan = nuevoPlan;
        // Lógica para cambiar el plan del usuario
    }
}
