package com.lab4;

public class Libro implements Producto {
    @Override
    public void listar() {
        // Lógica para listar información del libro
    }
}
